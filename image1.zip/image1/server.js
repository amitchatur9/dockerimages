'use strict';

const express = require('express');

// Constants
const PORT = 8080;
const HOST = '0.0.0.0';

// App
const app = express();
app.get('/', (req, res) => {
  res.send('Hello you are in the container of  <B><H1><font color=green>IMAGE1</font></H1></B><br> Demo by <i><font color=blue><b>Amit C</b> </font></i>   \n ');
});

app.listen(PORT, HOST);
console.log(`Running on http://${HOST}:${PORT}`);